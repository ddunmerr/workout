// lib/domain/workout_repository.dart
import '/data/workout_api.dart';

abstract class WorkoutRepository {
  Future<int> getDistance();

  Future<void> setResistance(int level);
}

class WorkoutRepositoryImpl implements WorkoutRepository {
  final WorkoutApi api;

  WorkoutRepositoryImpl(this.api);

  @override
  Future<int> getDistance() async {
    return await api.getDistance();
  }

  @override
  Future<void> setResistance(int level) async {
    await api.setResistance(level);
  }
}
