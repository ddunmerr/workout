import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'data/workout_api.dart';
import 'domain/workout_repository.dart';
import 'view_model/workout_vm.dart';
import 'ui/workout_screen.dart';

void main() {
  // Создание всех зависимостей (API -> Repo -> ViewModel)
  final api = WorkoutApi('http://172.20.10.3'); // слой data
  final repo = WorkoutRepositoryImpl(api); // слой domain

  runApp(
    ChangeNotifierProvider(
      create: (_) => WorkoutViewModel(repo), // слой view_model
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Тренажёр-контроллер',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
      home: const WorkoutScreen(),
    );
  }
}
