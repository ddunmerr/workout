import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../view_model/workout_vm.dart';

class WorkoutScreen extends StatelessWidget {
  const WorkoutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<WorkoutViewModel>();

    return Scaffold(
      appBar: AppBar(title: const Text('Управление тренажёром')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: vm.isLoading
            ? const Center(child: CircularProgressIndicator())
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Пройденное расстояние:',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${vm.distance} м',
                    style: Theme.of(context).textTheme.displaySmall,
                  ),
                  const SizedBox(height: 32),
                  Text(
                    'Сопротивление: ${vm.resistance}',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        onPressed: vm.decreaseResistance,
                        child: const Text('-'),
                      ),
                      const SizedBox(width: 16),
                      ElevatedButton(
                        onPressed: vm.increaseResistance,
                        child: const Text('+'),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton(
                        onPressed: _startWorkout,
                        child: Text("Старт"),
                      ),
                      ElevatedButton(
                        onPressed: _stopWorkout,
                        child: Text("Стоп"),
                      ),
                      ElevatedButton(
                        onPressed: _resetWorkout,
                        child: Text("Сброс"),
                      ),
                    ],
                  ),

                  const SizedBox(height: 32),
                ],
              ),
      ),
    );
  }
}
