import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class Device {
  final String id;
  final String ip;

  Device({required this.id, required this.ip});

  factory Device.fromJson(Map<String, dynamic> json) {
    return Device(id: json['id'], ip: json['ip']);
  }
}

class ConnectScreen extends StatefulWidget {
  final void Function(String ip) onConnected;

  const ConnectScreen({super.key, required this.onConnected});

  @override
  State<ConnectScreen> createState() => _ConnectScreenState();
}

class _ConnectScreenState extends State<ConnectScreen> {
  List<Device> devices = [];
  bool isLoading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    fetchDevices();
  }

  Future<void> fetchDevices() async {
    final url = Uri.parse('https://your-server.com/api/devices?gym_id=1');
    try {
      final res = await http.get(url);
      if (res.statusCode == 200) {
        final List<dynamic> jsonList = jsonDecode(res.body);
        final fetchedDevices = jsonList
            .map((json) => Device.fromJson(json))
            .toList();
        setState(() {
          devices = fetchedDevices;
          isLoading = false;
        });
      } else {
        setState(() {
          error = 'Ошибка сервера: ${res.statusCode}';
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        error = 'Ошибка: $e';
        isLoading = false;
      });
    }
  }

  void onDeviceTap(Device device) {
    widget.onConnected(device.ip);
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        appBar: AppBar(title: const Text('Выбор тренажёра')),
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Выбор тренажёра')),
        body: Center(child: Text(error!)),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Выбор тренажёра')),
      body: ListView.builder(
        itemCount: devices.length,
        itemBuilder: (context, index) {
          final device = devices[index];
          return ListTile(
            title: Text(device.id),
            subtitle: Text(device.ip),
            onTap: () => onDeviceTap(device),
          );
        },
      ),
    );
  }
}
