import 'package:flutter/material.dart';
import '../domain/workout_repository.dart';
import 'dart:async';

class WorkoutViewModel extends ChangeNotifier {
  final WorkoutRepository repository;

  int _distance = 0;

  int get distance => _distance;

  int _resistance = 1;

  int get resistance => _resistance;

  bool _isLoading = false;

  bool get isLoading => _isLoading;

  Timer? _distanceTimer;

  WorkoutViewModel(this.repository) {
    _startDistanceUpdates();
  }

  void _startDistanceUpdates() {
    _distanceTimer = Timer.periodic(const Duration(seconds: 1), (timer) async {
      await _updateDistance();
    });
  }

  Future<void> _updateDistance() async {
    try {
      final d = await repository.getDistance();
      _distance = d;
      notifyListeners();
    } catch (e) {
      print('Ошибка при получении дистанции: $e');
    }
  }

  Future<void> increaseResistance() async {
    _resistance++;
    await _applyResistance();
  }

  Future<void> decreaseResistance() async {
    if (_resistance > 1) {
      _resistance--;
      await _applyResistance();
    }
  }

  Future<void> _applyResistance() async {
    try {
      await repository.setResistance(_resistance);
      notifyListeners();
    } catch (e) {
      print('Ошибка при установке сопротивления: $e');
    }
  }

  @override
  void dispose() {
    _distanceTimer?.cancel();
    super.dispose();
  }
}
