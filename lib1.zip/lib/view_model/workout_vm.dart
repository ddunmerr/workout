import 'package:flutter/material.dart';
import '../domain/workout_repository.dart';

class WorkoutViewModel extends ChangeNotifier {
  final WorkoutRepository repository;

  int _distance = 0;

  int get distance => _distance;

  int _resistance = 1;

  int get resistance => _resistance;

  bool _isLoading = false;

  bool get isLoading => _isLoading;

  WorkoutViewModel(this.repository);

  Future<void> loadDistance() async {
    _isLoading = true;
    notifyListeners();

    try {
      final d = await repository.getDistance();
      _distance = d;
    } catch (e) {
      print('Ошибка при получении дистанции: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> increaseResistance() async {
    _resistance++;
    await _applyResistance();
  }

  Future<void> decreaseResistance() async {
    if (_resistance > 1) {
      _resistance--;
      await _applyResistance();
    }
  }

  Future<void> _applyResistance() async {
    try {
      await repository.setResistance(_resistance);
      notifyListeners();
    } catch (e) {
      print('Ошибка при установке сопротивления: $e');
    }
  }
}
