import 'dart:convert';
import 'package:http/http.dart' as http;

class WorkoutApi {
  final String baseUrl;

  WorkoutApi(this.baseUrl);

  Future<int> getDistance() async {
    final res = await http.get(Uri.parse('$baseUrl/distance.php'));
    final json = jsonDecode(res.body);
    return json['distance'];
  }

  Future<void> setResistance(int level) async {
    await http.post(
      Uri.parse('$baseUrl/resistance.php'),
      body: jsonEncode({'resistance': level}),
      headers: {'Content-Type': 'application/json'},
    );
    print(baseUrl);
  }
}
